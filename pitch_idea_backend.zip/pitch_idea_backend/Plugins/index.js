
module.exports = [
    { register: require('./swagger')}
    ,{ register: require('./good-console')}
    ,{ register: require('./auth-token')}
];