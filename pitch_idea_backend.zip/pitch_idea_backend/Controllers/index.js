
module.exports  = {

    UserController:require('./UserController'),
    AdminController:require('./AdminController'),
};