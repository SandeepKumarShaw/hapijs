/**
 * Created by Shumi Gupta on 29/3/17.
 */

module.exports = {
    APP_CONSTANTS: require('./appConstants'),
    dbConfig: require('./dbConfig'),
    // smsConfig: require('./smsConfig'),
     awsS3Config: require('./awsS3Config'),
    // emailConfig: require('./emailConfig')
};