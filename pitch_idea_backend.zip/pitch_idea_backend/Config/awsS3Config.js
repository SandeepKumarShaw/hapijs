'use strict';
let s3BucketCredentials = {
    "bucket": "pitchidea1",
    "accessKeyId": "AKIAI343LMBS42D66ECA",
    "secretAccessKey": "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",
    "s3URL": "https://s3-us-west-2.amazonaws.com/pitchidea1/"
};

module.exports = {
    s3BucketCredentials: s3BucketCredentials
};
