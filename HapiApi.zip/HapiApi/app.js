const Hapi = require('hapi');

const server = new Hapi.Server({
  host: 'localhost',
  port: 3000
});
const mongoose = require('mongoose');

const routes = require("./routes/product");

mongoose.connect('mongodb://localhost/node-hapi');

// Add the route
server.route({  
    method: 'GET',
    path:'/',
    handler: function (request, h) {

        return 'Here the books will be shown soon...';
    }
});

server.route(routes);


// Start the server
server.start((err) => {

    if (err) {
        throw err;
    }
    console.log('Server running at:', server.info.uri);
});