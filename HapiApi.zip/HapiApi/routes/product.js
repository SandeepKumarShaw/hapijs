const mongoose      = require('mongoose');

const ProductController = require('../controllers/products');

module.exports = [
    {
        path: '/api/products',
        method: 'POST',
        handler: ProductController.create
    },
    {
        path: '/api/products',
        method: 'GET',
        handler: ProductController.getAll
    },
    {
        path: '/api/products/{id}',
        method: 'GET',
        handler: ProductController.get
    },
    {
        path: '/api/products/{id}',
        method: 'PUT',
        handler: ProductController.update
    },
    {
        path: '/api/products/{id}',
        method: 'DELETE',
        handler: ProductController.delete
    }
 
];
