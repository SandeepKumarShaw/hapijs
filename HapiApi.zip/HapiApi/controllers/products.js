const mongoose = require('mongoose');
const Product  = require("../models/products");

module.exports = {
    create(req, h) {
	  	const product = {
            name: req.payload.name,
            price: req.payload.price
        }
		return Product.create(product)
		.then(function(result){
			return {
				mesage:"created",
				result:result
			};

		})
		.catch(function(err){
	      return { err: err };
		});
	},
	getAll(req, h) {	  	
		return Product.find({}).exec()
		.then(function(result){
			return {
				result:result
			};

		})
		.catch(function(err){
	      return { err: err };
		});
	},
	get(req, h) {	  	
		return Product.findById(req.params.id).exec()
		.then(function(result){
			if(!result) return { message: 'result not Found' };
			return {
				result:result
			};

		})
		.catch(function(err){
	      return { err: err };
		});
	},
	update(req, h) {	  	
		return Product.findById(req.params.id).exec()
		.then(function(result){
			if(!result) return { message: 'result not Found' };
				/*const product = {
	            result.name: req.payload.name,
	            result.price: req.payload.price
	        };*/
	        const product = {
            name: req.payload.name,
            price: req.payload.price
        }
	        Product.save(product);
			

		}).then(function(data){
          return { message: "data updated successfully" };

		})
		.catch(function(err){
	      return { err: err };
		});
	},
	delete(req, h) {	  	
		return Product.findById(req.params.id).exec(function (err, product) {
		    if (err) return { dberror: err };
		    if (!product) return { message: 'Product not found' };

		    product.remove(function (err) {
		      if (err) return { dberror: err };

		      return { success: true };
		    });
		});
	}
};